const mineflayer = require('mineflayer');
const config = require('./config.json');

// 🎨 Colors
const colors = {
  reset: "\x1b[0m",
  red: "\x1b[31m",
  green: "\x1b[32m",
  yellow: "\x1b[33m",
  blue: "\x1b[34m",
  magenta: "\x1b[35m",
  cyan: "\x1b[36m",
  white: "\x1b[37m",
  bold: "\x1b[1m",
};

// ⏰ Timestamp Logger
function log(prefix, color, message) {
  const time = new Date().toLocaleTimeString();
  console.log(`${colors.bold}[${time}]${colors.reset} ${color}${prefix}${colors.reset} ${message}`);
}

let bot;
let playerCount = 0;
let intervals = [];

// Clear intervals
function clearAllIntervals() {
  for (const id of intervals) clearInterval(id);
  intervals = [];
}

// Bot Creator
function createBot() {
  bot = mineflayer.createBot({
    host: config.host,
    port: config.port,
    username: config.username
  });

  bot.on('spawn', () => {
    log("✅ [SPAWN]", colors.green, "Bot has joined the server!");

    // Current players online
    playerCount = Object.keys(bot.players).length - 1;
    log("👥 [PLAYERS]", colors.cyan, `Currently online: ${colors.bold}${playerCount}${colors.reset}`);

    // Movement loop
    intervals.push(setInterval(() => {
      bot.setControlState('jump', true);
      bot.setControlState('forward', true);
      setTimeout(() => bot.clearControlStates(), 500 + Math.random() * 1000);
    }, config.movementInterval));

    // Chat loop
    intervals.push(setInterval(() => {
      bot.chat(config.chatMessage);
      log("💬 [CHAT]", colors.magenta, "Message sent.");
    }, config.chatInterval));

    // Restart check loop
    intervals.push(setInterval(checkPlayerCountAndRestart, config.restartInterval));
  });

  bot.on('playerJoined', (player) => {
    if (player.username !== bot.username) {
      playerCount++;
      log("➡️ [JOIN]", colors.yellow, `${player.username} joined. Total: ${colors.bold}${playerCount}${colors.reset}`);
    }
  });

  bot.on('playerLeft', (player) => {
    if (player.username !== bot.username) {
      playerCount--;
      log("⬅️ [LEAVE]", colors.yellow, `${player.username} left. Total: ${colors.bold}${playerCount}${colors.reset}`);
    }
  });

  bot.on('error', (err) => {
    log("⚠️ [ERROR]", colors.red, err.message);
  });

  bot.on('end', () => {
    log("❌ [END]", colors.red, `Bot disconnected. Reconnecting in ${config.reconnectDelay / 1000}s...`);
    clearAllIntervals();
    setTimeout(createBot, config.reconnectDelay);
  });
}

// Restart Check
function checkPlayerCountAndRestart() {
  if (playerCount === 0) {
    log("🔄 [RESTART]", colors.blue, "No players online. Sending /stop...");
    bot.chat('/stop'); // only works if OP
  } else {
    log("👥 [STATUS]", colors.green, `Players online: ${colors.bold}${playerCount}${colors.reset} | Server stays running.`);
  }
}

// Start Bot
createBot();